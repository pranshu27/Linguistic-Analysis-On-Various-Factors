python3 q1.py
