python3 q9.py
