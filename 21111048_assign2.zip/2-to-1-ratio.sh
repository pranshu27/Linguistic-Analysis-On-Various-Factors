python3 q4-b.py
